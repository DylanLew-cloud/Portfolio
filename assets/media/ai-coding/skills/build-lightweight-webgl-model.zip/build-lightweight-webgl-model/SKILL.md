---
name: build-lightweight-webgl-model
description: Build or add a compact, dependency-free interactive 3D model viewer for a single untextured OBJ asset using native WebGL. Use when a site needs a lightweight rotatable logo, sculpture, product form, or abstract model without Three.js; includes OBJ decimation, responsive rendering, pointer controls, accessibility, motion preferences, and static fallback guidance.
---

# Lightweight WebGL Model

Build one focused interactive model display. Prefer this workflow only for static geometry with a simple material; use a full renderer for glTF, animation, textures, PBR, multiple materials, scenes, or advanced camera controls.

## Workflow

1. Confirm the source is a clean OBJ containing `v` and polygonal `f` records. Preserve the original asset.
2. Run `scripts/optimize-obj.mjs` to create a web copy. Start with `--ratio 0.01`; lower the ratio if contours noticeably change. The optimiser intentionally drops UVs, normals, groups, materials, and duplicate triangles.
3. Use a static `<img>` or poster as the baseline. Do not hide it until WebGL initializes successfully.
4. Create a canvas renderer that:
   - loads the optimised OBJ (or its optional inline bundle), triangulates faces, centres and uniformly normalises it, and calculates smooth vertex normals;
   - caps backing-store pixel ratio at 2, uses `ResizeObserver`, and chooses `Uint16Array` unless `OES_element_index_uint` supports larger meshes;
   - has a transparent clear colour, depth testing, and at least one directional light; make colour, initial rotation, camera distance, and field of view public configuration rather than model-specific constants;
   - supports pointer capture for drag rotation, ignores click-like drags using a small movement threshold, and cleans up listeners/observers when the component is removed;
   - renders only while visible or changing. Stop idle rotation when the document is hidden.
5. Respect `prefers-reduced-motion`: disable idle rotation and all animated camera transitions. Keep drag rotation available.
6. Give the canvas an accessible label and keyboard-reachable reset control. If WebGL, fetch, parsing, or index support fails, retain the poster and expose no broken interactive affordance.

## Optimise an OBJ

```powershell
node scripts/optimize-obj.mjs source.obj public/model.web.obj --ratio 0.01
```

For file-based local previews that cannot fetch an OBJ, create an explicit inline bundle:

```powershell
node scripts/optimize-obj.mjs source.obj public/model.web.obj --ratio 0.01 --inline public/model.web.js --global __modelObj
```

Load the bundle before the viewer script and read `window.__modelObj` before attempting `fetch`. Keep the source OBJ as the canonical editable model; commit only the generated web asset that the site serves.

## Validation

- Compare the original and optimised silhouette at the intended display size before accepting the ratio.
- Test the poster fallback by disabling WebGL or forcing the model request to fail.
- Test mouse, touch, keyboard reset, resize, page visibility, and reduced-motion behavior.
- Check that the viewer remains responsive on a high-DPI mobile viewport and has no console errors.

## Scope boundaries

Do not embed client-specific contact cards, target coordinates, branded shaders, fixed art direction, or a model-specific focus pose in this skill. Treat every visual decision as caller-provided configuration.
