import fs from 'node:fs';
import path from 'node:path';

const usage = 'Usage: node optimize-obj.mjs input.obj output.obj [--ratio 0.01 | --cell 3.6] [--inline bundle.js] [--global __modelObj]';
const [inputPath, outputPath, ...flags] = process.argv.slice(2);
if (!inputPath || !outputPath) throw new Error(usage);

let ratio = 0.01;
let cellSize;
let inlinePath;
let globalName = '__modelObj';
for (let index = 0; index < flags.length; index += 1) {
  const flag = flags[index];
  const value = flags[index + 1];
  if (!['--ratio', '--cell', '--inline', '--global'].includes(flag) || value === undefined) throw new Error(usage);
  index += 1;
  if (flag === '--ratio') ratio = Number(value);
  if (flag === '--cell') cellSize = Number(value);
  if (flag === '--inline') inlinePath = value;
  if (flag === '--global') globalName = value;
}
if (!Number.isFinite(ratio) || ratio <= 0 || ratio > 1) throw new Error('--ratio must be greater than 0 and at most 1');
if (cellSize !== undefined && (!Number.isFinite(cellSize) || cellSize <= 0)) throw new Error('--cell must be greater than 0');
if (!/^[A-Za-z_$][\w$]*$/.test(globalName)) throw new Error('--global must be a JavaScript identifier');

const vertices = [];
const polygons = [];
for (const line of fs.readFileSync(inputPath, 'utf8').split(/\r?\n/)) {
  const parts = line.trim().split(/\s+/);
  if (parts[0] === 'v' && parts.length >= 4) {
    const point = parts.slice(1, 4).map(Number);
    if (point.every(Number.isFinite)) vertices.push(point);
  }
  if (parts[0] === 'f' && parts.length >= 4) {
    const polygon = parts.slice(1).map((reference) => {
      const raw = Number(reference.split('/')[0]);
      return raw < 0 ? vertices.length + raw : raw - 1;
    });
    if (polygon.every((vertex) => Number.isInteger(vertex) && vertex >= 0 && vertex < vertices.length)) polygons.push(polygon);
  }
}
if (!vertices.length || !polygons.length) throw new Error('Expected OBJ vertex (v) and face (f) records');

const min = [Infinity, Infinity, Infinity];
const max = [-Infinity, -Infinity, -Infinity];
for (const vertex of vertices) {
  for (let axis = 0; axis < 3; axis += 1) {
    min[axis] = Math.min(min[axis], vertex[axis]);
    max[axis] = Math.max(max[axis], vertex[axis]);
  }
}
const extent = Math.max(...max.map((value, axis) => value - min[axis]));
if (!Number.isFinite(extent) || extent === 0) throw new Error('The model must occupy 3D space');
const effectiveCellSize = cellSize ?? extent * ratio;

const clusters = new Map();
const vertexCluster = new Uint32Array(vertices.length);
for (let index = 0; index < vertices.length; index += 1) {
  const vertex = vertices[index];
  const key = vertex.map((value, axis) => Math.floor((value - min[axis]) / effectiveCellSize)).join(':');
  let cluster = clusters.get(key);
  if (!cluster) {
    cluster = { sum: [0, 0, 0], count: 0, index: clusters.size };
    clusters.set(key, cluster);
  }
  for (let axis = 0; axis < 3; axis += 1) cluster.sum[axis] += vertex[axis];
  cluster.count += 1;
  vertexCluster[index] = cluster.index;
}

const faces = new Map();
for (const polygon of polygons) {
  const references = polygon.map((index) => vertexCluster[index]);
  for (let index = 1; index < references.length - 1; index += 1) {
    const triangle = [references[0], references[index], references[index + 1]];
    if (new Set(triangle).size !== 3) continue;
    const key = [...triangle].sort((a, b) => a - b).join(':');
    if (!faces.has(key)) faces.set(key, triangle);
  }
}
if (!faces.size) throw new Error('Optimisation removed every valid triangle; use a smaller ratio or cell size');

const output = [
  '# Optimised for a simple native WebGL viewer',
  ...[...clusters.values()].map((cluster) => `v ${cluster.sum.map((value) => value / cluster.count).join(' ')}`),
  ...faces.values().map((triangle) => `f ${triangle.map((index) => index + 1).join(' ')}`),
].join('\n') + '\n';

fs.mkdirSync(path.dirname(outputPath), { recursive: true });
fs.writeFileSync(outputPath, output);
if (inlinePath) {
  fs.mkdirSync(path.dirname(inlinePath), { recursive: true });
  fs.writeFileSync(inlinePath, `window.${globalName} = ${JSON.stringify(output)};\n`);
}
console.log(JSON.stringify({ inputVertices: vertices.length, outputVertices: clusters.size, outputTriangles: faces.size, cellSize: effectiveCellSize, ratio: cellSize ? undefined : ratio, inlinePath }, null, 2));
