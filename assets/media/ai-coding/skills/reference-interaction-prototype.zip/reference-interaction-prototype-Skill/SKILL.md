---
name: reference-interaction-prototype
description: Build and revise high-fidelity interactive UI prototypes from reference images, supplied visual assets, and a desired click or gesture flow. Use for watch, mobile, desktop, automotive, kiosk, or agent-interface demos where visual fidelity, motion, fixed layers, asset preservation, and state-transition review matter.
---

# Reference Interaction Prototype

Implement the supplied design faithfully, then inspect the complete interaction path. Treat supplied visual assets as part of the specification.

## 1. Establish the visual contract

- Inspect the project, reference images, and asset dimensions before editing.
- Record the target viewport, every screen phase, triggers, fixed layers, scrollable layers, supplied text/image layers, and expected timing.
- Preserve supplied text or composited PNG/SVG layers at their native aspect ratio. Use `contain`; do not recreate their typography or crop them unless asked.
- Identify visual elements that must stay fixed, such as a background, header, camera, or system controls. Keep them outside the scrolling container.
- When the specification is incomplete, make the smallest reversible assumption and state it.

## 2. Model interaction explicitly

- Define a finite, named phase type before implementing complex flows. Keep transient subphases separate when they own timing or different visual layers.
- For each phase, specify: entered-from event, entered and exited DOM, root CSS state class, animations, timers, and allowed interaction.
- Scope each timer to the phase it advances. Do not put delayed work for a later phase in an effect that is cleaned up during the current transition.
- Reset scroll and transient state at flow entry points. Clamp wheel and touch scrolling to a measured maximum.
- Use semantic interactive elements for clickable cards or popups. Preserve browser-reset styles required by the visual design.

## 3. Compose motion and material

- Animate page changes with one owner per transform. Disable obsolete entrance animations during a state transition so X/Y transforms and scales cannot compound accidentally.
- For a pure horizontal screen change, use `translate3d(x, 0, 0)` consistently across departing and arriving layers.
- During an overlap-prone transition, render only one instance of shared fixed information unless deliberate continuity requires otherwise.
- Build glass with a translucent base, broad soft refraction, and localized highlights. Avoid a uniform white outline unless the reference clearly has one.
- Keep motion meaningful: stagger content after its destination layer settles; preserve fixed layers above scrolling content with an explicit z-index plan.

## 4. Review before handing off

Perform the checks in order. Do not report success based only on a successful build.

1. Build and run the project using its documented commands.
2. Walk every user path from a fresh load, including all click, wait, and scroll states.
3. Inspect initial, mid-transition, and settled frames for each phase change.
4. At scroll limits, verify content does not cover fixed controls and the scrollbar agrees with the actual range.
5. Inspect computed root classes and transforms when an element is missing, duplicated, or moves diagonally.
6. Check the browser console and relevant automated tests.
7. Update the handoff with the current phase list, source-of-truth assets, launch/build commands, validation performed, and known limitations.

## Defect triage

| Symptom | Inspect first |
| --- | --- |
| A new screen is rendered but remains off-screen | Phase value, root CSS class, JSX condition, final transform |
| Follow-up items never appear | Effect cleanup and whether the timer belongs to the subsequent phase |
| Header, time, or orb appears twice | Simultaneous rendering of old and new fixed layers during transition |
| A transition slides diagonally | Competing animation/transform declarations |
| Background or camera scrolls | Fixed layer is inside the feed or has lower stacking priority |
| Text/image differs from reference | Asset aspect ratio, `object-fit`, cropping, and unintended CSS redraw |

## Completion report

State the completed interaction flow, validation actually performed, and any remaining visual assumptions. Link the source files that own the state machine and styling.
